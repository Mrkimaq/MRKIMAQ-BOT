let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
⚠️ *INFO BOT* ⚠️
Dibuat dengan javascript via NodeJs,Ffmpeg,dan ImageMagick

Rec: Drawl Nag
Script: @Nurotomo
Github: 
https://github.com/MRKIMAQ-BOT/

*Sosmed :*
Kritik kami di sosmed ataupun YouTube.
Instagram: @MR KIMAQ CANNEL
➥ YouTube:
youtube.com/MRKIMAQCANNEL

*Thanks To :*
ORANG TUA
PAKETAN
ALLAH SWT
Dan kawan yang lain :)

╠═〘 DONASI 〙 ═
╠➥ SmartFren: +62 882-3870-4645
╠➥ Tsel: 085325781631
╠➥ DANA : 085325781631
║>Request? http://wa.me/+6285325781631
╠═〘 INFO BOT 〙 ═
`.trim(), m)
}
handler.help = ['info']
handler.tags = ['info']
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

