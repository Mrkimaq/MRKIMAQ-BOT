let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Smartfren [088238704645]
│ • Telkomsel [085325781631]
│ • Gopay [085325781631]
╰────
╭─「 Hubungi 」
│ > Ingin donasi? http://wa.me/+6285325781631
╰────

Ini *#caranya untuk Donasi*
*Cara Donasi*:
1.) Beli ke pulsa/ konter terdekat semisal Indomaret
2.) Bilang ke konter terdekat..
"Beli pulsa telkomsel"
3.)Dan terus masukkan nomor kami 085325781631
4.) Jika sudah kirim bukti ke sini.. Terimakasih
*Kalau tidak juga gak papa*👍🏻
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
